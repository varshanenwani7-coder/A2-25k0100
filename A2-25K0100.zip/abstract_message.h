#ifndef ABSTRACTMESSAGE_H
#define ABSTRACTMESSAGE_H

class AbstractMessage {
public:
    virtual void displayMessage() const = 0;
    virtual ~AbstractMessage() {}
};

#endif
