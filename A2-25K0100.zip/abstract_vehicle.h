#ifndef ABSTRACTVEHICLE_H
#define ABSTRACTVEHICLE_H

#include <string>
using namespace std;

class AbstractVehicle {
public:
    virtual void displayVehicle() const = 0;
    virtual string getBrand() const = 0;
    virtual string getModel() const = 0;
    virtual int getYear() const = 0;
    virtual double getPrice() const = 0;
    virtual ~AbstractVehicle() {}
};

#endif
