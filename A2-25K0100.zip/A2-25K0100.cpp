#include <iostream>
#include <string>
#include <ctime>
#include "abstract_user.h"
#include "abstract_vehicle.h"
#include "abstract_listing.h"
#include "abstract_message.h"
using namespace std;

class User : public AbstractUser {
protected:
    const int userID;
    string name;
    string email;
    string password;
    string phone;
    bool isLoggedIn;

    static int totalUsers;

public:

    User() : userID(++totalUsers) {
        name = "Unknown";
        email = "";
        password = "";
        phone = "";
        isLoggedIn = false;
    }

    User(string n, string e, string p, string ph)
        : userID(++totalUsers) {
        name = n;
        email = e;
        password = p;
        phone = ph;
        isLoggedIn = false;
    }

    User(const User& other)
        : userID(++totalUsers) {
        name = other.name;
        email = other.email;
        password = other.password;
        phone = other.phone;
        isLoggedIn = false;
    }

    virtual void displayProfile() const {
        cout << "User ID: " << userID << endl;
        cout << "Name: " << name << endl;
        cout << "Email: " << email << endl;
        cout << "Phone: " << phone << endl;
    }

    string getName() const {
        return name;
    }

    int getUserID() const {
        return userID;
    }

    void login(string e, string p) {
        if(email == e && password == p) {
            isLoggedIn = true;
            cout << "Login successful\n";
        }
    }

    void logout() {
        isLoggedIn = false;
    }
};

int User::totalUsers = 0;


class Vehicle : public AbstractVehicle {
protected:
    const int vehicleID;
    string brand;
    string model;
    int year;
    double price;
    double mileage;

    static int totalVehicles;

public:

    Vehicle() : vehicleID(++totalVehicles) {
        brand = "Unknown";
        model = "Unknown";
        year = 0;
        price = 0;
        mileage = 0;
    }

    Vehicle(string b,string m,int y,double p,double mil)
        : vehicleID(++totalVehicles) {
        brand = b;
        model = m;
        year = y;
        price = p;
        mileage = mil;
    }

    virtual void displayVehicle() const {
        cout<<"Vehicle ID: "<<vehicleID<<endl;
        cout<<"Brand: "<<brand<<endl;
        cout<<"Model: "<<model<<endl;
        cout<<"Year: "<<year<<endl;
        cout<<"Price: "<<price<<endl;
    }

    string getBrand() const { return brand; }
    string getModel() const { return model; }
    int getYear() const { return year; }
    double getPrice() const { return price; }

};

int Vehicle::totalVehicles = 0;

class Car : public Vehicle {
private:
    int doors;

public:
    Car() : Vehicle() {
        doors = 4;
    }

    Car(string b,string m,int y,double p,double mil,int d)
    : Vehicle(b,m,y,p,mil) {
        doors = d;
    }

    void displayVehicle() const {
        cout<<"Car Details\n";
        Vehicle::displayVehicle();
        cout<<"Doors: "<<doors<<endl;
    }
};


class Bike : public Vehicle {
private:
    bool sports;

public:
    Bike() : Vehicle() {
        sports = false;
    }

    Bike(string b,string m,int y,double p,double mil,bool s)
    : Vehicle(b,m,y,p,mil) {
        sports = s;
    }

    void displayVehicle() const {
        cout<<"Bike Details\n";
        Vehicle::displayVehicle();
        cout<<"Sports Bike: "<<(sports?"Yes":"No")<<endl;
    }
};
class Truck : public Vehicle {
private:
    double loadCapacity;

public:
    Truck(string b, string m, int y, double p, double mil, double load)
    : Vehicle(b,m,y,p,mil) {
        loadCapacity = load;
    }

    void displayVehicle() const {
        cout << "Truck Details\n";
        Vehicle::displayVehicle();
        cout << "Load Capacity: " << loadCapacity << endl;
    }
};
class Bus : public Vehicle {
private:
    int seats;

public:
    Bus(string b, string m, int y, double p, double mil, int s)
    : Vehicle(b,m,y,p,mil) {
        seats = s;
    }

    void displayVehicle() const {
        cout << "Bus Details\n";
        Vehicle::displayVehicle();
        cout << "Seats: " << seats << endl;
    }
};
class LuxuryCar : public Car {
private:
    bool chauffeurService;

public:
    LuxuryCar(string b,string m,int y,double p,double mil,bool c)
    : Car(b,m,y,p,mil,4) {
        chauffeurService = c;
    }

    void displayVehicle() const {
        cout << "Luxury Car Details\n";
        Car::displayVehicle();
        cout << "Chauffeur Service: " << (chauffeurService ? "Yes" : "No") << endl;
    }
};

class Seller;

class Listing : public AbstractListing {
	
private:
    const int listingID;
    Vehicle* vehicle;
    Seller* seller;
    double price;
    bool approved;

    static int totalListings;

public:

    Listing() : listingID(++totalListings) {
        vehicle = NULL;
        seller = NULL;
        price = 0;
        approved = false;
    }

    Listing(Vehicle* v,Seller* s,double p)
    : listingID(++totalListings) {
        vehicle = v;
        seller = s;
        price = p;
        approved = false;
    }

    void setApproved(bool a) {
        approved = a;
    }

    double getPrice() const {
        return price;
    }

    bool getApprovalStatus() const {
        return approved;
    }

    void displayListing() const {
        cout<<"Listing ID: "<<listingID<<endl;
        cout<<"Price: "<<price<<endl;
        cout<<"Approved: "<<(approved?"Yes":"No")<<endl;
        if(vehicle!=NULL)
        vehicle->displayVehicle();
    }
    friend void showSecretListingInfo(Listing& l);
    friend class MaintenanceTool;
};

int Listing::totalListings = 0;



class Buyer : public User {
private:
    double wallet;

public:

    Buyer():User(){
        wallet=0;
    }

    Buyer(string n,string e,string p,string ph)
    :User(n,e,p,ph){
        wallet=0;
    }

    void addFunds(double amount){
        wallet+=amount;
    }

    void displayProfile() const {
        cout<<"Buyer Profile\n";
        User::displayProfile();
        cout<<"Wallet: "<<wallet<<endl;
    }
};



class Seller : public User {
private:
    double earnings;

public:

    Seller():User(){
        earnings=0;
    }

    Seller(string n,string e,string p,string ph)
    :User(n,e,p,ph){
        earnings=0;
    }

    void addEarnings(double amount){
        earnings+=amount;
    }

    void displayProfile() const {
        cout<<"Seller Profile\n";
        User::displayProfile();
        cout<<"Earnings: "<<earnings<<endl;
    }
};
class PremiumSeller : public Seller {
private:
    int rating;

public:
    PremiumSeller(string n, string e, string p, string ph, int r)
    : Seller(n, e, p, ph) {
        rating = r;
    }

    void displayProfile() const {
        cout << "Premium Seller Profile\n";
        Seller::displayProfile();
        cout << "Rating: " << rating << endl;
    }
};



class Admin : public User {
	
private:
    string role;

public:

    Admin():User(){
        role="Moderator";
    }

    Admin(string n,string e,string p,string ph,string r)
    :User(n,e,p,ph){
        role=r;
    }

    void displayProfile() const {
        cout<<"Admin Profile\n";
        User::displayProfile();
        cout<<"Role: "<<role<<endl;
    }
    friend void adminAudit(Admin& a);
};
class Message : public AbstractMessage {
public:
    void displayMessage() const {
        cout << "System Message" << endl;
    }
};

bool operator>(const Vehicle& v1, const Vehicle& v2) {
    return v1.getPrice() > v2.getPrice();
}

bool operator<(const Vehicle& v1, const Vehicle& v2) {
    return v1.getPrice() < v2.getPrice();
}



Listing operator+(const Listing& l1, const Listing& l2) {
    Listing temp;
    double total = l1.getPrice() + l2.getPrice();
    temp.setApproved(false);
    return temp;
}



bool operator==(const User& u1,const User& u2) {
    return u1.getUserID() == u2.getUserID();
}



ostream& operator<<(ostream& out,const Vehicle& v) {
    out<<"Vehicle: "
       <<v.getBrand()<<" "
       <<v.getModel()
       <<" Price: "<<v.getPrice()<<endl;
    return out;
}



Buyer operator+(Buyer b,double amount) {
    b.addFunds(amount);
    return b;
}



Seller operator+(Seller s,double amount) {
    s.addEarnings(amount);
    return s;
}



bool operator>=(const Listing& l1,const Listing& l2) {
    return l1.getPrice() >= l2.getPrice();
}



double operator-(const Vehicle& v1,const Vehicle& v2) {
    return v1.getPrice() - v2.getPrice();
}








void showSecretListingInfo(Listing& l) {
    cout << "SECRET LISTING INFO" << endl;
    cout << "Price: " << l.price << endl;
    cout << "Approved: " << (l.approved ? "Yes" : "No") << endl;
    cout << "Vehicle Details Accessed Privately" << endl;
}



class MaintenanceTool {
public:
    void resetListing(Listing& l) {
        l.approved = false;
        cout << "Listing reset successfully by Maintenance Tool" << endl;
    }

    void boostListingPrice(Listing& l, double amount) {
        l.price += amount;
        cout << "Listing price boosted by Maintenance Tool" << endl;
    }
};



void adminAudit(Admin& a) {
    cout << "ADMIN AUDIT REPORT" << endl;
    cout << "Role: " << a.role << endl;
    cout << "System Check Completed" << endl;
}
int main() {

    Vehicle v1("Toyota", "Corolla", 2018, 15000, 50000);
    Vehicle v2("Honda", "Civic", 2020, 20000, 30000);

    Car c1("Toyota", "Corolla", 2018, 15000, 50000, 4);
    Bike b1("Yamaha", "R15", 2022, 3000, 15000, true);

    Seller s1("Ali", "ali@gmail.com", "1234", "0300");
    Buyer b("Sara", "sara@gmail.com", "5678", "0311");
    Admin a("Admin", "admin@gmail.com", "admin", "0321", "SuperAdmin");
    PremiumSeller ps1("Ahmed", "ahmed@gmail.com", "1111", "0300", 5);
LuxuryCar lc1("BMW", "7 Series", 2023, 90000, 10000, true);
cout << "\n===== LUXURY CAR =====" << endl;
lc1.displayVehicle();


    Listing l1(&v1, &s1, 15000);
    Listing l2(&v2, &s1, 20000);

    l1.setApproved(true);
    l2.setApproved(true);

    cout << "===== VEHICLE DISPLAY =====" << endl;
    v1.displayVehicle();
    v2.displayVehicle();
    cout << "\n===== PREMIUM SELLER =====" << endl;
    ps1.displayProfile();

    cout << "\n===== POLYMORPHISM =====" << endl;
    c1.displayVehicle();
    b1.displayVehicle();

    cout << "\n===== LISTINGS =====" << endl;
    l1.displayListing();
    l2.displayListing();

    cout << "\n===== OPERATOR OVERLOADING =====" << endl;

    cout << (v2 > v1 ? "v2 is expensive" : "v1 is expensive") << endl;
    cout << "Price difference: " << (v2 - v1) << endl;

    Buyer b2 = b + 5000;
    Seller s2 = s1 + 1000;

    cout << "\nBuyer funds added\n";
    cout << "Seller earnings updated\n";

    cout << "\n===== FRIEND FUNCTIONS =====" << endl;
    showSecretListingInfo(l1);

    MaintenanceTool tool;
    tool.resetListing(l2);
    tool.boostListingPrice(l2, 2000);

    cout << "\n===== ADMIN AUDIT =====" << endl;
    adminAudit(a);

    cout << "\n===== END PROGRAM =====" << endl;

    return 0;
}
