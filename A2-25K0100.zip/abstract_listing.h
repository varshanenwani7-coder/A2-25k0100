#ifndef ABSTRACTLISTING_H
#define ABSTRACTLISTING_H

class AbstractListing {
public:
    virtual void displayListing() const = 0;
    virtual double getPrice() const = 0;
    virtual bool getApprovalStatus() const = 0;
    virtual ~AbstractListing() {}
};

#endif
